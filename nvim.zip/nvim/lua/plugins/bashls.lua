return {
  -- LSP for Bash
  {
    "neovim/nvim-lspconfig",
    dependencies = {
      "williamboman/mason.nvim",
      "williamboman/mason-lspconfig.nvim",
      "hrsh7th/cmp-nvim-lsp",
    },
    config = function()
      local lspconfig = require("lspconfig")
      local capabilities = require("cmp_nvim_lsp").default_capabilities()

      lspconfig.bashls.setup({
        capabilities = capabilities,
        filetypes = { "sh", "bash" },
        cmd = { "bash-language-server", "start" },
        root_dir = function(fname)
          return vim.fs.dirname(vim.fs.find({ ".git" }, { path = fname, upward = true })[1]) or vim.fn.getcwd()
        end,
        single_file_support = true,
      })
    end,
  },

  -- Format-on-save with conform.nvim
  {
    "stevearc/conform.nvim",
    event = { "BufReadPre", "BufNewFile" },
    config = function()
      local conform = require("conform")
      conform.setup({
        formatters_by_ft = {
          sh = { "shfmt" },
          bash = { "shfmt" },
        },
        formatters = {
          shfmt = {
            prepend_args = { "-i", "2", "-ci" }, -- indent=2, indent case blocks
          },
        },
      })

      vim.api.nvim_create_autocmd("BufWritePre", {
        callback = function(args)
          conform.format({
            bufnr = args.buf,
            timeout_ms = 3000,
            lsp_fallback = false,
          })
        end,
      })
    end,
  },

  -- Mason setup
  {
    "williamboman/mason.nvim",
    config = function()
      require("mason").setup()
    end,
  },

  -- mason-lspconfig for auto LSP install
  {
    "williamboman/mason-lspconfig.nvim",
    config = function()
      require("mason-lspconfig").setup({
        ensure_installed = { "bashls" },
        automatic_installation = true,
      })
    end,
  },

  -- Install formatters/linters
  {
    "WhoIsSethDaniel/mason-tool-installer.nvim",
    config = function()
      require("mason-tool-installer").setup({
        ensure_installed = {
          "shfmt",
          "shellcheck",
        },
        auto_update = true,
        run_on_start = true,
      })
    end,
  },

  -- nvim-cmp for autocompletion
  {
    "hrsh7th/nvim-cmp",
    dependencies = {
      "hrsh7th/cmp-nvim-lsp",
      "hrsh7th/cmp-buffer",
      "hrsh7th/cmp-path",
      "hrsh7th/cmp-cmdline",
      "L3MON4D3/LuaSnip",
      "saadparwaiz1/cmp_luasnip",
    },
    config = function()
      local cmp = require("cmp")
      local luasnip = require("luasnip")

      cmp.setup({
        snippet = {
          expand = function(args)
            luasnip.lsp_expand(args.body)
          end,
        },
        mapping = cmp.mapping.preset.insert({
          ["<CR>"] = cmp.mapping.confirm({ select = true }),
          ["<Tab>"] = cmp.mapping(function(fallback)
            if cmp.visible() then
              cmp.select_next_item()
            elseif luasnip.expand_or_jumpable() then
              luasnip.expand_or_jump()
            else
              fallback()
            end
          end, { "i", "s" }),
          ["<S-Tab>"] = cmp.mapping(function(fallback)
            if cmp.visible() then
              cmp.select_prev_item()
            elseif luasnip.jumpable(-1) then
              luasnip.jump(-1)
            else
              fallback()
            end
          end, { "i", "s" }),
        }),
        sources = cmp.config.sources({
          { name = "nvim_lsp" },
          { name = "luasnip" },
        }, {
          { name = "buffer" },
          { name = "path" },
        }),
      })
    end,
  },

  -- none-ls for diagnostics
  {
    "nvimtools/none-ls.nvim",
    dependencies = { "nvim-lua/plenary.nvim" },
    config = function()
      local null_ls = require("null-ls")
      null_ls.setup({
        sources = {
          null_ls.builtins.formatting.shfmt.with({
            extra_args = { "-i", "2", "-ci" },
          }),
          null_ls.builtins.diagnostics.shellcheck,
          null_ls.builtins.code_actions.shellcheck,
        },
        on_attach = function(client)
          if client.name == "bashls" then
            client.server_capabilities.documentFormattingProvider = false
          end
        end,
      })
    end,
  },

  -- Register tools with Mason
  {
    "jay-babu/mason-null-ls.nvim",
    config = function()
      require("mason-null-ls").setup({
        ensure_installed = {
          "shfmt",
          "shellcheck",
        },
        automatic_installation = true,
      })
    end,
  },
}

