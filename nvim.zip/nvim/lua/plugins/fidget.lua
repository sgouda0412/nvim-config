return {
    "j-hui/fidget.nvim",
    opts = {
        -- options
    },
    config = function()
        require("fidget").setup({})
    end
}
