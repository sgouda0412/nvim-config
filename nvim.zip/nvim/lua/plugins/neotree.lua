return {
    {
        "nvim-neo-tree/neo-tree.nvim",
        branch = "v3.x",
        dependencies = {
            "nvim-lua/plenary.nvim",
            "nvim-tree/nvim-web-devicons",
            "MunifTanjim/nui.nvim",
        },
        config = function()
            local icons = {
                kinds = {
                    Folder = "",
                    File = "",
                    FolderOpen = "",
                },
                git = {
                    added = "",
                    modified = "",
                    removed = "",
                    renamed = "➜",
                    untracked = "",
                    ignored = "",
                    unstaged = "",
                    staged = "",
                    conflict = "",
                }
            }

            -- ============================
            -- CTRL+E KEYMAPS (REPLACED ALL LEADER MAPPINGS)
            -- ============================
            
            -- Main toggle (original <leader>e)
            vim.keymap.set('n', '<C-o>', ':Neotree toggle<CR>', { silent = true, noremap = true, desc = "Toggle Neo-tree" })
            
            -- Focus and reveal mappings
            vim.keymap.set('n', '<C-e>o', ':Neotree focus<CR>', { silent = true, noremap = true, desc = "Focus Neo-tree" })
            vim.keymap.set('n', '<C-e>f', ':Neotree reveal<CR>', { silent = true, noremap = true, desc = "Reveal current file" })
            vim.keymap.set('n', '<C-e>F', ':Neotree reveal_force_cwd<CR>', { silent = true, noremap = true, desc = "Reveal file and change cwd" })
            
            -- Panel toggles
            vim.keymap.set('n', '<C-e>g', ':Neotree toggle git_status<CR>', { silent = true, noremap = true, desc = "Toggle Git status" })
            vim.keymap.set('n', '<C-e>b', ':Neotree toggle buffers<CR>', { silent = true, noremap = true, desc = "Toggle Buffers" })
            
            -- File operations
            vim.keymap.set('n', '<C-e>h', function()
                local state = require("neo-tree.sources.manager").get_state("filesystem")
                if state then
                    local filters = state.filtered_items
                    filters.visible = not filters.visible
                    filters.hide_dotfiles = not filters.hide_dotfiles
                    filters.hide_gitignored = not filters.hide_gitignored
                    require("neo-tree.sources.filesystem")._navigate_internal(state, nil, nil)
                end
            end, { noremap = true, silent = true, desc = "Toggle Hidden Files" })

            -- Directory navigation
            vim.keymap.set('n', '<C-e>d', function()
                local current_file = vim.fn.expand('%:p:h')
                vim.cmd('Neotree dir=' .. current_file)
            end, { noremap = true, silent = true, desc = "Neo-tree to current file directory" })

            -- Parent directory navigation
            vim.keymap.set('n', '<C-e>u', function()
                local current_file = vim.fn.expand('%:p:h:h')
                vim.cmd('Neotree dir=' .. current_file)
            end, { noremap = true, silent = true, desc = "Neo-tree to parent directory" })

            -- ============================
            -- ENHANCED NEO-TREE SETUP
            -- ============================
            
            require("neo-tree").setup({
                close_if_last_window = true,
                popup_border_style = "rounded",
                enable_git_status = true,
                enable_diagnostics = true,
                
                default_component_configs = {
                    container = { enable_character_fade = true },
                    indent = {
                        indent_size = 2,
                        padding = 1,
                        with_markers = true,
                        indent_marker = "│",
                        last_indent_marker = "└",
                        highlight = "NeoTreeIndentMarker",
                    },
                    icon = {
                        folder_closed = icons.kinds.Folder,
                        folder_open = icons.kinds.FolderOpen,
                        folder_empty = "",
                        default = icons.kinds.File,
                        highlight = "NeoTreeFileIcon"
                    },
                    modified = { symbol = "[+]", highlight = "NeoTreeModified" },
                    name = {
                        trailing_slash = false,
                        use_git_status_colors = true,
                        highlight = "NeoTreeFileName",
                    },
                    git_status = { symbols = icons.git },
                },
                
                window = {
                    position = "left",
                    width = 35,
                    mappings = {
                        ["<space>"] = "toggle_node",
                        ["<2-LeftMouse>"] = "open",
                        ["<cr>"] = "open",
                        ["<C-e>"] = "close_window",  -- Added Ctrl+e in Neo-tree to close
                        ["h"] = "close_node",
                        ["l"] = "open",
                        ["S"] = "open_split",
                        ["s"] = "open_vsplit",
                        ["t"] = "open_tabnew",
                        ["a"] = "add",
                        ["A"] = "add_directory",
                        ["d"] = "delete",
                        ["r"] = "rename",
                        ["y"] = "copy_to_clipboard",
                        ["x"] = "cut_to_clipboard",
                        ["p"] = "paste_from_clipboard",
                        ["c"] = "copy",
                        ["m"] = "move",
                        ["q"] = "close_window",
                        ["R"] = "refresh",
                        ["?"] = "show_help",
                    }
                },
                
                filesystem = {
                    filtered_items = {
                        visible = true,
                        hide_dotfiles = false,
                        hide_gitignored = false,
                        hide_by_name = { "node_modules" },
                        never_show = { ".DS_Store", "thumbs.db" },
                    },
                    follow_current_file = { enabled = true },
                    group_empty_dirs = false,
                    hijack_netrw_behavior = "open_current",
                    use_libuv_file_watcher = false,
                    window = {
                        mappings = {
                            ["<bs>"] = "navigate_up",
                            ["."] = "set_root",
                            ["H"] = "toggle_hidden",
                            ["/"] = "fuzzy_finder",
                        }
                    },
                },
                
                buffers = {
                    follow_current_file = { enabled = true },
                    group_empty_dirs = true,
                    show_unloaded = true,
                },
                
                git_status = {
                    window = { position = "float" }
                }
            })

            -- Auto-close Neo-tree when it's the last window
            vim.api.nvim_create_autocmd("QuitPre", {
                callback = function()
                    local invalid_win = {}
                    local wins = vim.api.nvim_list_wins()
                    for _, w in ipairs(wins) do
                        local bufname = vim.api.nvim_buf_get_name(vim.api.nvim_win_get_buf(w))
                        if bufname:match("neo%-tree") ~= nil then
                            table.insert(invalid_win, w)
                        end
                    end
                    if #invalid_win == #wins - 1 then
                        for _, w in ipairs(invalid_win) do
                            vim.api.nvim_win_close(w, true)
                        end
                    end
                end
            })
        end
    }
}
