return {
  'nvim-orgmode/orgmode',
  event = 'VeryLazy',
  ft = { 'org' },
  config = function()
    -- Setup orgmode
    require('orgmode').setup({
      org_agenda_files = '~/orgfiles/**/*',
      org_default_notes_file = '~/orgfiles/refile.org',
    })
    
    -- FIXED: Only install essential parsers
    require('nvim-treesitter.configs').setup({
      ensure_installed = { 'lua', 'vim', 'vimdoc', 'query' }, -- Just basics
      ignore_install = { 'org' },
      auto_install = false, -- Prevent automatic downloads
      sync_install = false, -- Don't block Neovim startup
    })
  end,
}
