return {
  -- Autoformat using conform.nvim
  "stevearc/conform.nvim",
  event = { "BufWritePre" },
  cmd = { "ConformInfo" },
  keys = {
    {
      "<C-s>",
      function()
        require("conform").format({ 
          async = false,  -- Changed to synchronous to ensure formatting completes before save
          lsp_format = "fallback" 
        })
        vim.cmd("write")
      end,
      desc = "[F]ormat buffer and save",
    },
    {
      "<C-s>",
      function()
        require("conform").format({ 
          async = false,  -- Changed to synchronous
          lsp_format = "fallback" 
        })
        vim.cmd("write")
      end,
      mode = "i",
      desc = "[F]ormat buffer and save",
    },
  },
  opts = {
    notify_on_error = false,
    format_on_save = function(bufnr)
      -- Disable format-on-save for certain filetypes if needed
      local disable_filetypes = { }  -- Removed c and cpp to enable formatting
      if disable_filetypes[vim.bo[bufnr].filetype] then
        return
      end
      return {
        timeout_ms = 500,  -- Increased timeout from 10ms to 500ms
        lsp_format = "fallback",
      }
    end,
    formatters_by_ft = {
      lua = { "stylua" },
      python = { "isort", "black" },
      javascript = { { "prettierd", "prettier" } },
      typescript = { { "prettierd", "prettier" } },
      javascriptreact = { { "prettierd", "prettier" } },
      typescriptreact = { { "prettierd", "prettier" } },
      vue = { { "prettierd", "prettier" } },
      css = { { "prettierd", "prettier" } },
      scss = { { "prettierd", "prettier" } },
      less = { { "prettierd", "prettier" } },
      html = { { "prettierd", "prettier" } },
      json = { { "prettierd", "prettier" } },
      jsonc = { { "prettierd", "prettier" } },
      yaml = { { "prettierd", "prettier" } },
      markdown = { { "prettierd", "prettier" } },
      graphql = { { "prettierd", "prettier" } },
      handlebars = { { "prettierd", "prettier" } },
      sh = { "shfmt" },
      bash = { "shfmt" },
      zsh = { "shfmt" },
      fish = { "fish_indent" },
      go = { "goimports", "gofmt" },
      rust = { "rustfmt" },
      c = { "clang_format" },
      cpp = { "clang_format" },
      java = { "google-java-format" },
      xml = { "xmlformat" },
      ["*"] = { "codespell" },
      ["_"] = { "trim_whitespace" },
    },
    formatters = {
      shfmt = {
        prepend_args = { "-i", "2" },
      },
    },
  },
}
