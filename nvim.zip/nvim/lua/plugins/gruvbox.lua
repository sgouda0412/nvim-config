return {
	"morhetz/gruvbox",
	lazy = false,
	priority = 999,
	config = function()
		vim.cmd("colorscheme gruvbox")
	end,
}
