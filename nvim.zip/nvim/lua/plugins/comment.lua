return {
	"numToStr/Comment.nvim",
	opts = {
		toggler = {
			line = "gtc",
			block = "gtb",
		},
		opleader = {
			line = "goc",
			block = "gob",
		},
	},
	lazy = false,
}
