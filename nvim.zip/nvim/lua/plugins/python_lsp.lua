return {
    -- Ruff LSP (handles linting + formatting)
    {
        "neovim/nvim-lspconfig",
        opts = {
            servers = {
                ruff_lsp = {
                    on_attach = function(client, bufnr)
                        -- Disable formatting in Ruff if you're using Black (or vice versa)
                        client.server_capabilities.documentFormattingProvider = false
                        client.server_capabilities.documentRangeFormattingProvider = false

                        vim.keymap.set("n", "<C-f>", function()
                            vim.lsp.buf.format({ async = true })
                        end, { buffer = bufnr, desc = "Format with LSP" })
                    end,
                },
            },
        },
    },

    -- null-ls (for mypy + optional Black)
    {
        "nvimtools/none-ls.nvim",
        event = { "BufReadPre", "BufNewFile" },
        dependencies = { "nvim-lua/plenary.nvim" },
        config = function()
            local null_ls = require("null-ls")

            -- Fix mypy issues by using the virtualenv's Python
            local mypy_cmd = {
                "python",
                "-m",
                "mypy",
                "--show-column-numbers",
                "--hide-error-context",
                "--no-color-output",
                "--no-error-summary",
                "--no-pretty",
            }

            null_ls.setup({
                debug = true, -- Temporarily enable for debugging
                sources = {
                    -- Mypy with better args
                    null_ls.builtins.diagnostics.mypy.with({
                        command = "python",
                        runtime_condition = function()
                            return vim.fn.filereadable("pyproject.toml") == 1 or vim.fn.filereadable("setup.cfg") == 1
                        end,
                        extra_args = {
                            "--ignore-missing-imports",
                            "--follow-imports=silent",
                            "--show-error-codes",
                        },
                    }),

                    -- Optional: Black formatter
                    null_ls.builtins.formatting.black.with({
                        extra_args = { "--line-length=88", "--fast" },
                    }),
                },
            })
        end,
    },
    -- Python execution
    -- {
    --   "akinsho/toggleterm.nvim",
    --   version = "*",
    --   keys = {
    --     -- Run current file in floating terminal
    --     {
    --       "<leader>rr",
    --       function()
    --         vim.cmd("w")
    --         require("toggleterm").exec("python " .. vim.fn.expand("%"), 1, 15, nil, "float")
    --       end,
    --       desc = "Run Python (float)",
    --     },
    --     -- Run with debug output
    --     {
    --       "<leader>rd",
    --       function()
    --         vim.cmd("w")
    --         require("toggleterm").exec("python -u " .. vim.fn.expand("%") .. " | tee /tmp/python_output", 1, 30, nil, "horizontal")
    --       end,
    --       desc = "Run Python (debug)",
    --     },
    --   },
    --   config = true, -- Enable default configurations
    -- },
    {
        "akinsho/toggleterm.nvim",
        version = "*",
        keys = {
            { "<C-t>", "<cmd>ToggleTerm<cr>", desc = "Toggle Terminal" },
        },
        config = function()
            require("toggleterm").setup({
                direction = "horizontal",
                size = 15,
                close_on_exit = true,
                start_in_insert = true,
            })

            -- Close terminal with Ctrl-q in terminal mode
            vim.keymap.set("t", "<C-q>", [[<C-\><C-n>:q<CR>]], { silent = true })
        end,
    },
    -- Debugging (optional)
    {
        "mfussenegger/nvim-dap",
        dependencies = {
            "mfussenegger/nvim-dap-python",
            "rcarriga/nvim-dap-ui",
        },
        ft = "python",
        keys = {
            { "<F5>",  function() require("dap").continue() end,  desc = "Debug: Start/Continue" },
            { "<F10>", function() require("dap").step_over() end, desc = "Debug: Step Over" },
        },
        config = function()
            require("dap-python").setup("python")
            require("dapui").setup()
        end,
    },

    -- Quick execution without terminal
    {
        "folke/which-key.nvim",
        init = function()
            vim.keymap.set("n", "<leader>rq", function()
                vim.cmd("w")
                vim.cmd("!python %")
            end, { desc = "Quick-run Python" })
        end,
    },
}
