#!/usr/bin/env bash







echo 'if [ $1 -eq 1 ];then
echo "test"
fi' | shfmt -ci -s -bn
