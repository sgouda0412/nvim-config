require("config.icons")
require("config.lazy")
require("config.keymaps")
require("config.autocmds")
require("config.options")
vim.cmd([[
  set guicursor=
  let &t_SI = "\e[6 q"
  let &t_EI = "\e[6 q"
  let &t_SR = "\e[6 q"
]])

local lsp_format_group = vim.api.nvim_create_augroup("LspFormat", { clear = true })

vim.api.nvim_create_autocmd("LspAttach", {
  group = lsp_format_group,
  callback = function(args)
    local client = vim.lsp.get_client_by_id(args.data.client_id)
    local bufnr = args.buf

    -- Only if the server supports formatting
    if client and client.server_capabilities.documentFormattingProvider then
      vim.api.nvim_create_autocmd("BufWritePre", {
        group = lsp_format_group,
        buffer = bufnr,
        callback = function()
          vim.lsp.buf.format({
            async = false,
            filter = function(c)
              return c.id == client.id
            end,
          })
        end,
      })
    end
  end,
})
--vim.keymap.set({ "n", "i" }, "<C-s>", "<Esc>:w<CR>", { silent = true })
vim.keymap.set("n", "<C-s>", ":w<CR>", { silent = true })
vim.keymap.set("i", "<C-s>", "<Esc>:w<CR>i", { silent = true })
--vim.keymap.set("n", "<Leader>s", ":w<CR>", { silent = true })
--vim.keymap.set("i", "<Leader>s", "<Esc>:w<CR>a", { silent = true })
